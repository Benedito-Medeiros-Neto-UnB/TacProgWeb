from django.apps import AppConfig


class SiteEstConfig(AppConfig):
    name = 'site_est'
