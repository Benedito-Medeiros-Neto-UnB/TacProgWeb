# Projeto Educaçã0 3.0 - Tópicos Avançados em Computadores

Versão do Django - (2, 2, 7, 'final', 0)

Versão do Python - 2.7.12

Versão do Python3 - 3.5.2

Para rodar o Projeto entre na pasta principal atraves do terminal e digite sem as aspas 'python3 manage.py runserver'

Acesse o endereço 'http://localhost:8000/' atraves de um navegador.

Lembrando que para rodar o projeto corretamente, o ambiente de desenvolvimento deve esta preparado, ou seja, o Django, o Python e suas dependencias devem estar instalados.

Projeto sem fins lucrativos - Lucas Ribas - 160052289
